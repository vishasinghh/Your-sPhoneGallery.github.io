

There are mainly 3 pages

    sign-in/sign-up
    Homepage
    About Us / Contact Us

The Languages which i have used are HTML, CSS, JavaScirpt and PHP The name of the website is "TheAxiosGarage" which is based on the given topic Car Selling. The website is hosted on Github.

How To ----->

Run on local host

Landing page -> Log-in page

The User Data base is stored in database hosted on "phpmyadmin", an open source database host.

Then the user will land on the Log in page.

Two options availabe on home page (i) Contact Us (ii) Log Out

The accordingly you will be redirected to Contact US page Or Logout Page.

THANK YOU
